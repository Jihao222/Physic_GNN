import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from datetime import datetime
from scipy.optimize import curve_fit

now1 = datetime.now()
savestr = now1.strftime('%m.%d-%H.%M.%S.%f')
Si = '(ode_1 + ode_2 + ode_3 + 100mse_3 + bou_u0 + bou_u1)-训练了10000次'

myfont = fm.FontProperties(fname='/font/simhei.ttf', size=66, weight='normal')
linewid = 4
tickl = 16
myfont1 = fm.FontProperties(fname='/font/timesbd.ttf', size=66, weight='normal')
bb = 2  # 1.5

fig = plt.figure(figsize=(40, 30), facecolor='white', edgecolor='white')
ax1 = fig.add_subplot(111)
ax1.grid(False)
ax1.tick_params(bottom=True, axis='x', direction='out', which='major', length=tickl, width=linewid, color='k')
ax1.tick_params(left=True, axis='y', direction='out', which='major', length=tickl, width=linewid, color='k')

ax1.patch.set_facecolor('white')
ax1.spines['top'].set_color('black')
ax1.spines['top'].set_visible(True)
ax1.spines['top'].set_linewidth(linewid)
ax1.spines['bottom'].set_color('black')
ax1.spines['bottom'].set_visible(True)

ax1.spines['bottom'].set_linewidth(linewid)
ax1.spines['right'].set_color('black')
ax1.spines['right'].set_visible(True)
ax1.spines['right'].set_linewidth(linewid)
ax1.spines['left'].set_color('black')
ax1.spines['left'].set_visible(True)
ax1.spines['left'].set_linewidth(linewid)

M_H2 = 2
d_e = 1.905 * 0.001  # 喷口直径
T = 273.15 + 20
M_air = 28.959
midu_air = 1.293 * 1 * (273.15 / T)

# openfoam数据
file_lilunwen = r'李论文中竖直射流实验数据-有速度.csv'
data_lilunwen = pd.read_csv(file_lilunwen)
x_20 = data_lilunwen['z/d_e'].values
#u_true = data_lilunwen['u_jia'].values
u_true = data_lilunwen['u_RK'].values
# PIGNN预测的数据
file_PIGNN = 'PIGNN\output\((ode_1 + ode_2 + ode_3 + 100mse_3 + bou_u0 + bou_u1)-已知Fr)-07.14-16_13_39-训练10000.csv'
data_PIGNN = pd.read_csv(file_PIGNN)
u_PIGNN = data_PIGNN['u_pred'].values
# PINN预测的数据
file_PINN = 'PINN\output\(ode_1 + ode_2 + ode_3 + ode_4 + 100mse_3 + bou_u0+ 归一化后的u(0,-1))-已知Fr-07.14-16_42_16-[0, 1, 8, 15, 19]-训练10000.csv'
data_PINN = pd.read_csv(file_PINN)
u_PINN = data_PINN['u_pred'].values

file_PINN_best = 'PINN\output\(ode_1 + ode_2 + ode_3 + ode_4 + 100mse_3 + bou_u0+ 归一化后的u(0,-1))-已知Fr-07.19-12_04_40-[0, 1, 8, 15, 19]-训练30000.csv'
data_PINN_best = pd.read_csv(file_PINN_best)
u_PINN_best = data_PINN_best['u_pred'].values

ax1.plot(x_20, u_PINN, label='u_cl predicted by PINN', color='orange', linewidth=linewid*bb)
#ax1.plot(x_20, u_PINN_best, label='Best u_cl predicted by PINN', color='blue', linewidth=linewid*bb)

ax1.scatter(x_20, u_true, label="u_cl predicted by OpenFOAM", marker='^', c='green', linewidths=linewid*bb, s=700)

ax1.plot(x_20, u_PIGNN, label="u_cl predicted by PIGNN", color='red', linewidth=linewid*bb)

ax1.set_xlabel('Dimensionless distance: S/d_e', fontproperties=myfont1)
ax1.set_ylabel('Velocity: u_cl', fontproperties=myfont1)
ax1.legend(loc=1, prop=myfont1, ncol=1)
#ax1.set_ylim(0, 4.5)
#ax1.set_xlim(1855.5, 1875.5)

for axlab in ax1.get_xticklabels()+ax1.get_yticklabels():
    axlab.set_fontproperties(myfont1)

plt.savefig(rf'fig_u\{savestr}-{Si}-速度对比曲线.png')
plt.show()
print('结束')