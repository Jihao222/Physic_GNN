import pandas as pd
from datetime import datetime
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm

myfont = fm.FontProperties(fname='/font/simhei.ttf', size=66, weight='normal')
linewid = 4
tickl = 16
myfont1 = fm.FontProperties(fname='/font/timesbd.ttf', size=66, weight='normal')
bb = 2

fig = plt.figure(figsize=(40, 30),facecolor='white', edgecolor='white')
ax1 = fig.add_subplot(111)
ax1.grid(False)
ax1.tick_params(bottom=True, axis='x', direction='out', which='major', length=tickl, width=linewid, color='k')
ax1.tick_params(left=True, axis='y', direction='out', which='major', length=tickl, width=linewid, color='k')

ax1.patch.set_facecolor('white')
ax1.spines['top'].set_color('black')
ax1.spines['top'].set_visible(True)
ax1.spines['top'].set_linewidth(linewid)
ax1.spines['bottom'].set_color('black')
ax1.spines['bottom'].set_visible(True)

ax1.spines['bottom'].set_linewidth(linewid)
ax1.spines['right'].set_color('black')
ax1.spines['right'].set_visible(True)
ax1.spines['right'].set_linewidth(linewid)
ax1.spines['left'].set_color('black')
ax1.spines['left'].set_visible(True)
ax1.spines['left'].set_linewidth(linewid)

M_H2 = 2
d_e = 1 * 0.001  # 喷口直径
T = 273.15 + 20
M_air = 28.959
midu_air = 1.293 * 1 * (273.15 / T)

now = datetime.now()
now_str = now.strftime('%m.%d-%H_%M_%S')
Si = '(ode_1 + ode_2 + ode_3 + 100mse_3 + bou_u0 + bou_u1)-10bar-训练了10000次'
# 论文中的实验数据
file_lilunwen = r'李论文中高压竖直射流实验数据-10barRe3665.02-有速度.csv'
data_lilunwen = pd.read_csv(file_lilunwen)
x_20 = data_lilunwen['z/d_e'].values
y_true = data_lilunwen['X_cl'].values
# PIGNN预测的数据
file_PIGNN = 'PIGNN\output\((ode_1 + ode_2 + ode_3 + 100mse_3 + + 归一化后的u(0-1))-已知midu_leak-1)-07.18-17_19_32-训练10000.csv'
data_PIGNN = pd.read_csv(file_PIGNN)
midu_PIGNN = data_PIGNN['midu_pred'].values
y_PIGNN = M_H2 / (M_air - M_H2) * (midu_air / midu_PIGNN - 1)
# PINN预测的数据
file_PINN = 'PINN\output\(ode_1 + ode_2 + ode_3 + 100mse_3 + bou_u0+ 归一化后的u(0,-1))-已知midu_leak-1-07.18-17_29_34-训练10000.csv'
data_PINN = pd.read_csv(file_PINN)
midu_PINN = data_PINN['midu_pred'].values
y_PINN = M_H2 / (M_air - M_H2) * (midu_air / midu_PINN - 1)

file_PINN_best = 'PINN\output\(ode_1 + ode_2 + ode_3 + 100mse_3 + bou_u0+ 归一化后的u(0,-1))-已知midu_leak-1-07.19-00_09_02-训练30000.csv'
#file_PINN_best = 'PINN\output\(ode_1 + ode_2 + ode_3 + 100mse_3 + bou_u0+ 归一化后的u(0,-1))-已知midu_leak-1-07.19-11_33_43-训练20000.csv'
data_PINN_best = pd.read_csv(file_PINN_best)
midu_PINN_best = data_PINN_best['midu_pred'].values
y_PINN_best = M_H2 / (M_air - M_H2) * (midu_air / midu_PINN_best - 1)

ax1.scatter(x_20, y_true, label="Y_cl measured in experiment", marker='^', color='green', linewidths=linewid*bb, s=700)
ax1.plot(x_20, y_PINN, label="Y_cl predicted by PINN", color='orange', linewidth=linewid*bb)
#ax1.plot(x_20, y_PINN_best, label="Best Y_cl predicted by PINN", color='royalblue', linewidth=linewid*bb)
ax1.plot(x_20, y_PIGNN, label="Y_cl predicted by Physic_GNN", color='red', linewidth=linewid*bb)
ax1.set_xlabel('Dimensionless distance: S/d_e', fontproperties=myfont1)
ax1.set_ylabel('Concentration: Y_cl', fontproperties=myfont1)  #
ax1.legend(loc=1, prop=myfont1, ncol=1)

for axlab in ax1.get_xticklabels() + ax1.get_yticklabels():
    axlab.set_fontproperties(myfont1)

plt.savefig(rf'fig\{now_str}-{Si}-沿射流中心线的摩尔分数.png')
plt.show()
plt.clf()