import tensorflow as tf
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
import time
np.random.seed(1234)
tf.compat.v1.random.set_random_seed(1234)

def min_max_normalized(Input):
    max_val = np.max(Input)
    min_val = np.min(Input)
    normalized_data = (Input - min_val)/(max_val - min_val)
    return normalized_data, min_val, max_val

def min_max_normalize_inverse(Input, min_val, max_val):
    return Input * (max_val - min_val) + min_val

# 射流参数
T = 273.15 + 20
g = 9.80665
M_H2 = 2
M_air = 28.959
P_air = 101325
R = 8.314
midu_air = 1.293 * 1 * (273.15 / T)
midu_H2 = 0.08342  # 氢气在标准大气压、温度下的密度
midu_gas = midu_H2 * (273.15 / T)  # 在环境大气压、温度下的密度

langmuda = 1.528
beita_A = 0.281
jian_1 = langmuda ** 2 / (1 + langmuda ** 2)
jian_2 = 2 * langmuda ** 2 / (1 + 2 * langmuda ** 2)
beita_S = 8.631
beita_B = 0.820

P_0 = 10 * 100000
d_e = 0.003
d_ps = 0.021
u_ps = 1176
midu_leak = 0.0838
Fr_ps = u_ps/np.sqrt(g * d_ps * np.abs(midu_leak-midu_air)/midu_leak)
Fr_den = Fr_ps
S_ps = beita_S * d_ps
B_ps = beita_B * d_ps

# training sample points
file_lilunwen = '高压水平射流数据.csv'
data_lilunwen = pd.read_csv(file_lilunwen)
z_de_lilunwen = data_lilunwen['z/d_e'].values
s_n20 = z_de_lilunwen * d_e
s_20_nor, s_min, s_max = min_max_normalized(s_n20)
data_train = [0, 1, 8, 15, 19]

# 标准的密度数据
x_cl = data_lilunwen['X_cl'].values
midu_n20 = midu_air / ((x_cl*(M_air - M_H2) / M_H2) + 1)
midu_n20_nor, midu_min, midu_max = min_max_normalized(midu_n20)
midu_n5_nor = np.take(midu_n20_nor, data_train)
midu_true = midu_n5_nor

# 标准的速度数据
u_cl = data_lilunwen['u_cl'].values
u_n20_nor, u_min, u_max = min_max_normalized(u_cl)

# 邻接矩阵
num_nodes = 20
adj_matrix0 = np.zeros((num_nodes, num_nodes))
diag_indices = np.diag_indices(min(adj_matrix0.shape))
adj_matrix0[diag_indices] = 1
adj_matrix = tf.constant(adj_matrix0, dtype=tf.float32)

s = tf.placeholder("float32", [20, ])
adjacency_matrix = adj_matrix
num_features = 4
node_features_de = tf.Variable(tf.random_normal([num_nodes, num_features]))

N_units = 30
epochs = 10000

def gnn(x):
    x1 = tf.expand_dims(x, axis=-1)
    y1 = tf.layers.dense(x1, 30, activation=tf.nn.softplus)
    y2 = tf.matmul(adjacency_matrix, y1)
    predicted_features = tf.layers.dense(y2, num_features, activation=tf.nn.softplus)
    return predicted_features
predicted_features = gnn(s)

# 定义损失函数
def loss_fn(predicted_features, s):
    u = predicted_features[:, 0]
    b = predicted_features[:, 1]
    midu = predicted_features[:, 2]
    seita = predicted_features[:, 3]
    dif_u = tf.gradients(u, s)
    dif_b = tf.gradients(b, s)
    dif_midu = tf.gradients(midu, s)
    dif_seita = tf.gradients(seita, s)

    y = M_H2 / (M_air - M_H2) * (midu_air / midu - 1)
    if Fr_den >= 268:
        a2 = 0.97
    else:
        a2 = 17.313 - 0.11664*Fr_den + 2.0771 * 0.0001 + Fr_den**2
    E_mom = beita_A * np.sqrt(np.pi * d_e ** 2 / 4 * midu_leak * u_ps ** 2 / midu_air)
    Fr_1 = u ** 2 / (g * b * (midu_air - midu) / midu_leak)
    E_buoy = a2 / Fr_1 * (2 * np.pi * u) * b
    E0 = E_mom + E_buoy  # 计算出来有可能是负数
    aerfa0 = E0 / (2 * np.pi * b * u)
    n_result = tf.reduce_all(tf.cast(aerfa0, tf.bool))
    if n_result is not None:
        aerfa00 = aerfa0
        weizhi = tf.greater(aerfa00, 0.082)
        aerfa = tf.where(weizhi, tf.fill(aerfa00.shape, 0.082), aerfa00)
        E = 2 * np.pi * b * aerfa * u
    else:
        E = 2 * np.pi * b * 0.082 * u
    o_1 = b ** 2 * (midu_air - jian_1 * (midu_air - midu)) * dif_u + 2 * u * b * \
          (midu_air - jian_1 * (midu_air - midu)) * dif_b + u * b ** 2 * jian_1 * dif_midu - midu_air * E / np.pi
    o_2 = (1 - jian_2 * (midu_air - midu) / midu_air) * \
          (u * tf.cos(seita) * b ** 2 * dif_u + u ** 2 * tf.sin(seita) * b ** 2 / 2 * dif_seita + u ** 2 * tf.cos(
              seita) * b * dif_b) + u ** 2 * tf.cos(seita) * b ** 2 / 2 * jian_2 * dif_midu / midu_air
    o_3 = midu * y * b ** 2 * dif_u + 2 * u * midu * y * b * dif_b + \
          u * b ** 2 * (y - M_H2 * M_air / (M_air - M_H2) * P_air / (R * T * midu)) * dif_midu
    o_4 = (1 - jian_2 * (midu_air - midu) / midu_air) * \
          (u * tf.sin(seita) * b ** 2 * dif_u + u ** 2 * tf.cos(seita) * b ** 2 / 2 * dif_seita + u ** 2 * tf.sin(
              seita) * b * dif_b) \
          + u ** 2 * tf.sin(seita) * b ** 2 / 2 * jian_2 * dif_midu / midu_air - (midu_air - midu) / midu_air \
          * g * langmuda ** 2 * b ** 2
    ode_1 = tf.reduce_sum(tf.square(o_1))
    ode_2 = tf.reduce_sum(tf.square(o_2))
    ode_3 = tf.reduce_sum(tf.square(o_3))
    ode_4 = tf.reduce_sum(tf.square(o_4))

    if midu_true.shape[0] == len(data_train):
        midu_m = tf.gather(midu, data_train)
        m_3 = tf.compat.v1.losses.mean_squared_error(midu_m, midu_true)
    else:
        m_3 = tf.losses.mean_squared_error(midu, midu_true)
    mse_3 = tf.reduce_sum(m_3)

    bou_u0 = tf.square(u[0]-u_n20_nor[0])
    bou_u1 = tf.square(u[-1]-u_n20_nor[-1])

    loss = ode_1 + ode_2 + ode_3 + ode_4 + 100*mse_3 + bou_u0 + bou_u1
    return loss, ode_1, ode_2, ode_3, ode_4, mse_3, bou_u0, bou_u1

loss, ode_1, ode_2, ode_3, ode_4, mse_3, bou_u0, bou_u1 = loss_fn(predicted_features, s)
optimizer = tf.compat.v1.train.AdamOptimizer(0.001).minimize(loss)
# 模型训练
with tf.compat.v1.Session() as sess:
    sess.run(tf.compat.v1.global_variables_initializer())

    s_t = np.zeros((len(s_20_nor), ))
    for i in range(len(s_20_nor)):
        s_t[i] = s_20_nor[i]
    # 训练
    loss_AllEpoch = []
    start_time = time.time()
    for epoch in range(epochs):
        sess.run(optimizer, feed_dict={s: s_t})
        # 训练中的损失项
        loss_train = sess.run(loss, feed_dict={s: s_t})
        ode_1_train = sess.run(ode_1, feed_dict={s: s_t})
        ode_2_train = sess.run(ode_2, feed_dict={s: s_t})
        ode_3_train = sess.run(ode_3, feed_dict={s: s_t})
        ode_4_train = sess.run(ode_4, feed_dict={s: s_t})
        mse_3_train = sess.run(mse_3, feed_dict={s: s_t})
        bou_u0_train = sess.run(bou_u0, feed_dict={s: s_t})
        bou_u1_train = sess.run(bou_u1, feed_dict={s: s_t})
        loss_AllEpoch.append(loss_train)
        if epoch % 100 == 0:
            print('------------------------------------------------')
            print("iteration={}".format(epoch))
            print("loss={}".format(loss_train))
            print("ode_1={}".format(np.ravel(ode_1_train)))
            print("ode_2={}".format(np.ravel(ode_2_train)))
            print("ode_3={}".format(np.ravel(ode_3_train)))
            print("ode_4={}".format(np.ravel(ode_4_train)))
            print("mse_3={}".format(np.ravel(mse_3_train)))
            print("bou_u0={}".format(np.ravel(bou_u0_train)))
            print("bou_u1={}".format(np.ravel(bou_u1_train)))
    end_time = time.time()
    training_time = end_time - start_time
    df7 = pd.DataFrame({'training_time': np.ravel(training_time)})
    now = datetime.now()
    now_str = now.strftime('%m.%d-%H_%M_%S')
    # 保存模型
    # tf.saved_model.save(model, f'竖直射流\model_trained\{now_str}-{Si}-{data_train}')
    # 画loss图
    plt.figure(1)
    plt.xlabel("Epoch")
    plt.ylabel("Loss")
    plt.plot(np.arange(epochs), loss_AllEpoch, label='Loss')
    plt.savefig(rf'PIGNN\Loss\{now_str}-{data_train}-训练{epochs}.png')
    #plt.show()
    # ===============================================
    # 用全部的节点测试模型
    predicted_features_data = sess.run(predicted_features, feed_dict={s: s_t})
    output0_u = predicted_features_data[:, 0]
    output0_b = predicted_features_data[:, 1]
    output0_midu = predicted_features_data[:, 2]
    output0_seita = predicted_features_data[:, 3]
    df1 = pd.DataFrame({'midu': midu_n20})
    output_midu = min_max_normalize_inverse(output0_midu, midu_min, midu_max)
    output_u = min_max_normalize_inverse(output0_u, u_min, u_max)
    df4 = pd.DataFrame({'u_pred': output_u, 'b_pred': output0_b, 'midu_pred': output_midu, 'seita_pred': output0_seita})
    # 测试中的损失
    m_3_test = np.mean((output0_midu - midu_n20_nor) ** 2)
    loss_test = sess.run(loss, feed_dict={s: s_t})
    ode_1_test = sess.run(ode_1, feed_dict={s: s_t})
    ode_2_test = sess.run(ode_2, feed_dict={s: s_t})
    ode_3_test = sess.run(ode_3, feed_dict={s: s_t})
    ode_4_test = sess.run(ode_4, feed_dict={s: s_t})
    mse_3_test_5 = sess.run(mse_3, feed_dict={s: s_t})
    bou_u0_test = sess.run(bou_u0, feed_dict={s: s_t})
    bou_u1_test = sess.run(bou_u1, feed_dict={s: s_t})
    df6 = pd.DataFrame({'loss': np.ravel(loss_test)})
    df5 = pd.DataFrame({'ode_1': np.ravel(ode_1_test), 'ode_2': np.ravel(ode_2_test),
                        'ode_3': np.ravel(ode_3_test), 'ode_4': np.ravel(ode_4_test),
                        'mse_3': np.ravel(m_3_test),
                        'bou_0': np.ravel(bou_u0_test), 'bou_-1': np.ravel(bou_u1_test)})
    df = pd.concat([df1, df4, df5, df6, df7], axis=1)
    df.to_csv(rf'PIGNN\output\{now_str}-{data_train}-训练{epochs}.csv', index=True)
print('结束')